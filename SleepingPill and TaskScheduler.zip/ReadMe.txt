If you know the settings you want to use:
Run Task Scheduler as administrator
Right-click on 'Task Scheduler Library' and choose 'Create Task'
Using the SleepingPill_x.PNG files as a guide, fill out the properties of the task
  Use your own settings when filling out the Arguments field of Edit Action.
When done, you should be asked to enter your administrator password again
Right-click on the new task and choose 'run'
The 'status' should show 'running' (also, Task Manager should show SleepingPill
  in the list of processes)
If there's a problem, SleepingPill will exit after a minute so wait that long
  before assuming all is well. If this happens, use the normal Windows menues
  to run SleepingPill as administrator. It should report the problem.

An alternate plan:
Use the normal Windows menues to create a shortcut of SleepingPill
In the target field of the shortcut properties, add the arguments you think
  you want; leave blank for default values.
Click 'Apply' then run the shortcut as administrator
Run your screen saver or just wait for it to run automatically
Wait the amount of time defined by the settings for the computer to go to sleep
If the computer doesn't go to sleep, then run a command prompt as administrator
  and enter PowerCfg /requests. Look at those requests under SYSTEM.
  Then enter PowerCfg /requestsoverride to see which requests can be ignored.
  Most likely, one of the SYSTEM requests is not overridden.
  Determine which request should be overridden and override it. Here are some
  examples of how:
    powercfg /requestsoverride process wmplayer.exe system
    powercfg /requestsoverride driver RealTek High Definition Audio system
    powercfg /requestsoverride service WebClient system
  For more detail, see:
  https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options#option_requestsoverride
Once you've determined which arguments you like, go to the top of the page
  and follow the instructions to create a SleepingPill task.
